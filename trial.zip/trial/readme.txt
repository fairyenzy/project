cara pemakaian Termux

1. pkg install python2
2. pkg install curl
3. pkg install termux-api
4. pip2 install colorama
5. pip2 install requests
6. pip2 install bs4
7. pkg update
8. pkg upgrade
9. run ( python2 doge.py )
10. untuk Stop Bot ( ctrl + 4 )


cara pemakaian VPS / Linux

1. apt-get install python2
2. apt-get install curl
3. apt-get install python-pip
4. pip2 install colorama
5. pip2 install requests
6. pip2 install bs4
7. pkg update
8. pkg upgrade
9. run ( python2 doge.py )
10. untuk Stop Bot ( ctrl + c )