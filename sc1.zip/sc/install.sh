apt install python2 -y
apt install python3 -y
apt install python-pip
apt install curl -y
apt install termux-api -y
pip2 install mime
pip2 install colorama
pip2 install requests
pip2 install bs4

